#include<iostream>
using namespace std;
int main(){
    int num,result;
    num=1;
    result=0;
    while (num<=100)
    {
        result=result+num;
        num=num+2;
    }
    cout<<"The Result Of Odd Numbers Between 1 to 100 is => "<<result<<endl;









}